/*****************************************************************
//
//  NAME:        Chase Lee
//
//  HOMEWORK:    homework7a
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        March 21, 2020
//
//  FILE:        paint.h
//
//  DESCRIPTION:
//   This is a header file that contains the function prototype 
//   for "costofpainting" this shows what the function returns
//   and what it accepts
//
****************************************************************/

/*****************************************************************
//
//  Function name: costofpainting
//
//  DESCRIPTION:   A function that calculates the total amount it takes
//                 to paint stripes
//
//  Parameters:    length (double) : contains the length that is to
//                                   be painted
//
//  Return values:  cost : the total cost of a painting
//                  -1 : when given an incorrect length functions fails and returns -1 
//
****************************************************************/
double costofpainting(double length);
