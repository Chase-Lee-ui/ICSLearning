/*****************************************************************
//
//  NAME:        Chase Lee
//
//  HOMEWORK:    homework7b
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        April 1, 2020
//
//  FILE:        homework7b.c
//
//  DESCRIPTION:
//    This file contains the source code for reading and modifying a 
//    gif and creates a new modified gif file. This also prints out
//    the color codes, width and height of a gif
//
****************************************************************/

#include <stdio.h>
void printinfor(unsigned char []);
void modify(unsigned char []);
int readfile(unsigned char [], int*, char[]);
int writefile(unsigned char[], int, char[]); 

/*****************************************************************
//
//  Function name: main
//
//  DESCRIPTION:   The main function that displays the info of a gif
//                 before and after modification
//
//  Parameters:    argc (int) : contains the number of arguments
//                 argv (char*) : contains the string argument
//
//  Return values:  0 : success
//
****************************************************************/

int main(int argc, char* argv[])
{
    unsigned char gif[4000];
    int datasize;

    readfile(gif, &datasize, "image1.gif");
    printf("image1.gif file information before transformation:\n");
    printinfor(gif);
    modify(gif);
    printf("image1.gif file information after transformation:\n");
    printinfor(gif);
    writefile(gif, datasize, "result1.gif");

    readfile(gif, &datasize, "image2.gif");
    printf("image2.gif file information before transformation:\n");
    printinfor(gif);
    modify(gif);
    printf("image2.gif file information after transformation:\n");
    printinfor(gif);
    writefile(gif, datasize, "result2.gif");

    readfile(gif, &datasize, "image3.gif");
    printf("image3.gif file information before transformation:\n");
    printinfor(gif);
    modify(gif);
    printf("image3.gif file information after transformation:\n");
    printinfor(gif);
    writefile(gif, datasize, "result3.gif");

    return 0;
}

/*****************************************************************
//
//  Function name: printinfor
//
//  DESCRIPTION:   A function that displays the height and width of a gif file
//                 also shows the RGB of 4 colors
//
//  Parameters:    gif (unsigned char) : contains unsigned char gif file
//                                       information that's in a gif
//
//  Return values:  n/a
//
****************************************************************/

void printinfor(unsigned char gif[])
{
    int value = (gif[7]*256)+(gif[6]);

    printf("Width: (%d)\n", value);
    value = (gif[9]*256)+(gif[8]);
    printf("Height: (%d)\n", value);

    printf("Color 1:\n");
    printf("\tR value (%02X)\n", gif[13]);
    printf("\tG value (%02X)\n", gif[14]);
    printf("\tB value (%02X)\n", gif[15]);

    printf("Color 2:\n");
    printf("\tR value (%02X)\n", gif[16]);
    printf("\tG value (%02X)\n", gif[17]);
    printf("\tB value (%02X)\n", gif[18]);

    printf("Color 3:\n");
    printf("\tR value (%02X)\n", gif[19]);
    printf("\tG value (%02X)\n", gif[20]);
    printf("\tB value (%02X)\n", gif[21]);

    printf("Color 4:\n");
    printf("\tR value (%02X)\n", gif[22]);
    printf("\tG value (%02X)\n", gif[23]);
    printf("\tB value (%02X)\n\n", gif[24]);
}

/*****************************************************************
//
//  Function name: modify
//
//  DESCRIPTION:   A function that modifies a gif file, if all the value of an
//                 RGB color is more than 7F then it will be multiplied by 4
//                 and is modified a different way when under 7F
//
//  Parameters:    gif (unsigned char[]) : contains the gif information that
//                                         will be modified
//
//  Return values:  n/a
//
****************************************************************/

void modify(unsigned char gif[])
{
    if((gif[13] ^ 127) | (gif[14] ^ 127) | (gif[15] ^ 127))
    {
        gif[13] = (gif[13] << 2);
        gif[14] = (gif[14] << 2);
        gif[15] = (gif[15] << 2);
    }
    else
    {
        gif[13] = gif[13] & 222;
        gif[14] = (gif[14] << 4) | (gif[14] >> 4);
        gif[15] ^= 136;
    }

    if((gif[16] ^ 127) | (gif[17] ^ 127) | (gif[18] ^ 127))
    {
        gif[16] = (gif[16] << 2);
        gif[17] = (gif[17] << 2);
        gif[18] = (gif[18] << 2);
    }
    else
    {
        gif[16] = gif[16] & 222;
        gif[17] = (gif[17] <<4) | (gif[17] >> 4);
        gif[18] ^= 136;
    }

    if((gif[19] ^ 127) | (gif[20] ^ 127) | (gif[21] ^ 127))
    {
        gif[19] = (gif[19] << 2);
        gif[20] = (gif[20] << 2);
        gif[21] = (gif[21] << 2);
    }
    else
    {
        gif[19] = gif[19] & 222;
        gif[20] = (gif[20] << 4) | (gif[20] >> 4);
        gif[21] ^= 136;
    }

    if((gif[22] ^ 127) | (gif[23] ^ 127) | (gif[24] ^ 127))
    {
        gif[22] = (gif[22] << 2);
        gif[23] = (gif[23] << 2);
        gif[24] = (gif[24] << 2);
    }
    else
    {
        gif[22] = gif[22] & 222;
        gif[23] = (gif[23] << 4) | (gif[23] >> 4);
        gif[24] ^= 136;
    }

}

/*****************************************************************
//
//  Function name: readfile
//
//  DESCRIPTION:   A function that will read a gif file and store it in
//                 the unsigned char gif[] array
//
//  Parameters:    gif (unsigned char[]) : contains the information stored in
//                                         a  gif
//                 datasize : The pointer to an int that is stored in the main
//                            to show how much elements were copied
//                 file (char []) : the name of the file being read
//
//  Return values:  0 : success
//
****************************************************************/

int readfile(unsigned char gif[], int* datasize, char file[])
{
    FILE *fp;
    int size;
    fp = fopen(file, "r");
    fseek(fp, 0L, SEEK_END);
    size = ftell(fp);
    rewind(fp);
    (*datasize) = fread(gif, sizeof(unsigned char), size, fp);
    fclose(fp);
    return 0;
}

/*****************************************************************
//
//  Function name: writefile
//
//  DESCRIPTION:   A function that writes the information stored in gif
//                 to a file name given by file
//
//  Parameters:    gif (unsigned char[]) : contains the gif information
//                 datasize (int) : contains the amount of elements being 
//                                  written to a file
//                 file (char []) : contains the name of the file being
//                                  written to
//
//  Return values:  0 : success
//
****************************************************************/

int writefile(unsigned char gif[], int datasize, char file[])
{
    FILE *fp;

    fp = fopen(file, "w");
    fwrite(gif, 1, datasize, fp);
    fclose(fp);

    return 0;
}
