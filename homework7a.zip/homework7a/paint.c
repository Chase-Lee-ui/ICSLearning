/*****************************************************************
//
//  NAME:        Chase Lee
//
//  HOMEWORK:    homework7a
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        March 21, 2020
//
//  FILE:        paint.c
//
//  DESCRIPTION:
//   This file contains the code for the function "costofpainting"
//   this file takes in the function prototype from "paint.h" so that
//   the function can work.
//
****************************************************************/
#include <stdio.h>
#include "paint.h"

double costofpainting(double length)
{
    double cost = 300;

    if(length > 3)
    {
        cost = 3*cost + 50;
        length -= 3;
        cost = cost + costofpainting(0.7*length) + costofpainting(0.3*length);
    }
    else if(length <= 3 && length >= 0)
    {
        cost *= length;
    }
    else if(length < 0)
    {
        cost = -1;
    }
    
    return cost;
}
