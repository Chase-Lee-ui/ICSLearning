/*****************************************************************
//
//  NAME:        Chase Lee
//
//  HOMEWORK:    homework7a
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        March 21, 2020
//
//  FILE:        driver.c
//
//  DESCRIPTION:
//   This is a driver file for "paint.c" in which different lengths
//   are tested to see if the calculations come back correctly from
//   the recursive function in "paint.c"
//
****************************************************************/
#include <stdio.h>
#include "paint.h"

/*****************************************************************
//
//  Function name: main
//
//  DESCRIPTION:   The main will act as the driver for the function
//                 "costofpainting"
//
//  Parameters:    argc (int) : contains the number of arguments
//                 argv (char*) : contains the string of arguments
//
//  Return values:  0 : success
//
****************************************************************/
int main(int argc, char* argv[])
{
    double cost;

    printf("Test Case 1 -------------------------------------------\n");
    printf("Successful output = 4000.00 as given in the instructions.\n");
    cost = costofpainting(13);
    printf("Length: 13, Total cost: %.2f\n", cost);
    printf("-------------------------------------------------------\n\n");

    printf("Test Case 2 -------------------------------------------\n");
    printf("Successful output = 0.00\n");
    cost = costofpainting(0);
    printf("Length: 0, Total cost: %.2f\n", cost);
    printf("-------------------------------------------------------\n\n");

    printf("Test Case 3 -------------------------------------------\n");
    printf("Successful output = 31150.00\n");
    cost = costofpainting(100);
    printf("Length: 100, Total cost: %.2f\n", cost);
    printf("-------------------------------------------------------\n\n");

    printf("Test Case 4 -------------------------------------------\n");
    printf("Successful output = 953.00\n");
    cost = costofpainting(3.01);
    printf("Length: 100, Total cost: %.2f\n", cost);
    printf("-------------------------------------------------------\n\n");

    printf("Test Case 5 -------------------------------------------\n");
    printf("Successful output = 900.00\n");
    cost = costofpainting(3.00);
    printf("Length: 3, Total cost: %.2f\n", cost);
    printf("-------------------------------------------------------\n\n");

    printf("Test Case 5 -------------------------------------------\n");
    printf("Successful output = 897.00\n");
    cost = costofpainting(2.99);
    printf("Length: 2.99, Total cost: %.2f\n", cost);
    printf("-------------------------------------------------------\n\n");

    printf("Test Case 6 -------------------------------------------\n");
    printf("When given a negative length the function will return -1\n");
    cost = costofpainting(-13);
    printf("Lengt: -13, Total cost: %.2f\n", cost);
    printf("-------------------------------------------------------\n\n");

    return 0;
}
